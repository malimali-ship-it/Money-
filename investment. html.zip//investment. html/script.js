// server.js (updated)
app.post('/signup', async (req, res) => {
  const { firstName, lastName, email, password, confirmPassword } = req.body;

  // Check password match
  if (password !== confirmPassword) {
    return res.status(400).send('Passwords do not match');
  }

  // Basic email validation
  const emailRegex = /^[a-zA-Z0-9-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(email)) {
    return res.status(400).send('Invalid email');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({ firstName, lastName, email, password: hashedPassword });
  await user.save();
  res.send('User created!');
});
// client-side JS (add to fetch signup data)
const form = document.getElementById('signup');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = {
    firstName: form.firstName.value,
    lastName: form.lastName.value,
    email: form.email.value,
    password: form.password.value,
    confirmPassword: form.confirmPassword.value
  };
  const res = await fetch('/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  console.log(await res.text());
});
// client-side JS (add login fetch)
const loginForm = document.getElementById('login');
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = {
    email: loginForm.loginEmail.value,
    password: loginForm.loginPassword.value
  };
  const res = await fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  console.log(await res.text());
});
// server.js (update login route)
const jwt = require('jsonwebtoken');

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) {
    return res.status(400).send('Invalid email or password');
  }
  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).send('Invalid email or password');
  }
  const token = jwt.sign({ userId: user._id }, 'secretkey', { expiresIn: '1h' });
  res.json({ token });
});
// client-side JS (update login fetch)
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = {
    email: loginForm.loginEmail.value,
    password: loginForm.loginPassword.value
  };
  const res = await fetch('/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const result = await res.json();
  localStorage.setItem('token', result.token);
  console.log('Logged in!');
});
// server.js (add middleware)
const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  if (!token) {
    return res.status(401).send('Access denied');
  }
  try {
    const decoded = jwt.verify(token, 'secretkey');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).send('Invalid token');
  }
};

// Protect a route
app.get('/protected', authMiddleware, (req, res) => {
  res.send('Hello, authenticated user!');
});
// client-side JS (update fetch with token)
fetch('/protected', {
  headers: {
    Authorization: `Bearer ${localStorage.getItem('token')}`
  }
})
.then(res => res.text())
.then(data => console.log(data));
// server.js (update user schema)
const userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  email: String,
  password: String,
  role: { type: String, default: 'user' } // add role field
});
// server.js (update auth middleware)
const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  if (!token) {
    return res.status(401).send('Access denied');
  }
  try {
    const decoded = jwt.verify(token, 'secretkey');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).send('Invalid token');
  }
};

const adminMiddleware = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).send('Forbidden');
  }
  next();
};

// Protect admin route
app.get('/admin', authMiddleware, adminMiddleware, (req, res) => {
  res.send('Hello, admin!');
});
// server.js (add token blacklist)
const tokenBlacklist = new Set();

app.post('/logout', authMiddleware, (req, res) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  tokenBlacklist.add(token);
  res.send('Logged out!');
});

// Update auth middleware to check blacklist
const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  if (!token || tokenBlacklist.has(token)) {
    return res.status(401).send('Access denied');
  }
  try {
    const decoded = jwt.verify(token, 'secretkey');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(400).send('Invalid token');
  }
};
// server.js (update email verification)
const transporter = nodemailer.createTransport({
  host: 'smtp.mailtrap.io',
  port: 2525,
  auth: {
    user: 'your-mailtrap-username',
    pass: 'your-mailtrap-password'
  }
});

// Update verification email to use SA locale
transporter.sendMail({
  from: 'your-email@example.co.za',
  to: user.email,
  subject: 'Verify your email',
  text: `Click this link to verify: ${verificationLink}`,
  headers: { 'Accept-Language': 'en-ZA' }
});
const transporter = nodemailer.createTransport({
  host: 'smtp.mailtrap.io',
  port: 2525,
  auth: {
    user: 'your-mailtrap-username',
    pass: 'your-mailtrap-password'
  }
});
// unitTrust.model.js
const mongoose = require('mongoose');

const unitTrustSchema = new mongoose.Schema({
  name: String,
  type: String,
  currency: { type: String, default: 'ZAR' },
  performance: {
    oneYear: Number,
    threeYear: Number,
    fiveYear: Number
  },
  fees: {
    TER: Number,
    managementFee: Number
  }
});

module.exports = mongoose.model('UnitTrust', unitTrustSchema);
// unitTrust.model.js (updated)
const unitTrustSchema = new mongoose.Schema({
  name: String,
  type: String,
  currency: { type: String, default: 'ZAR' },
  performance: {
    twoWeek: Number,
    oneYear: Number,
    threeYear: Number,
    fiveYear: Number
  },
  fees: {
    TER: Number,
    managementFee: Number
  }
});
// Example response structure
const unitTrusts = [
  {
    name: 'Fund A',
    type: 'Equity',
    returns: {
      twoWeek: 1.2,
      oneMonth: 4.5
    }
  },
  // ... top 5 funds
];
// Populate table with data
// Define sample unit trusts data
const unitTrusts = [
  { name: 'Fund A', type: 'Equity', returns: { twoWeek: 2.5, oneMonth: 5 } },
  { name: 'Fund B', type: 'Balanced', returns: { twoWeek: 1.8, oneMonth: 4 } }
];

// Populate table with data
const tbody = document.getElementById('fund-data');
unitTrusts.forEach(fund => {
  tbody.innerHTML += `
    <tr>
      <td>${fund.name}</td>
      <td>${fund.type}</td>
      <td>${fund.returns.twoWeek}%</td>
      <td>${fund.returns.oneMonth}%</td>
    </tr>
  `;
});

// Fetch and display account balance
const accountId = 'your-account-id'; // replace with actual ID
fetch(`https:                                                   
  .then(response => response.json())
  .then(data => {
    document.getElementById('balance').innerText = `//api.investec.com/za/pb/v1/accounts/${accountId}`)
  .then(response => response.json())
  .then(data => {
    document.getElementById('balance').innerText = `R ${data.availableBalance}`;
  })
  .catch(error => console.error('Error fetching balance:', error));

// Example: Initiate payment
const paymentData = {
  beneficiaryId: 'Johnson Mthembu', // replace with real ID
  amount: 1000,
  reference: 'Payment' 
  const paymentData = {
  beneficiaryId: 'your-beneficiary-id',
  amount: 50, // R50 min deposit
  reference: 'Transfer'
};
// Check payment status using paymentId
fetch(`https://api.investec.com/za/pb/v1/payments/${paymentId}`)
  .then(response => response.json())
  .then(status => console.log('Latest status:', status));
https://api.investec.com/za/pb/v1/payments/${paymentIdfetch('https:                                      
  .then(response => response.json())
  .then(data => console.log('All payments:', data.payments));

